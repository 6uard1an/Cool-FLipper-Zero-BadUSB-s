Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

function Move-Mouse {
    $ScreenWidth = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
    $ScreenHeight = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height

    $Mouse = [System.Windows.Forms.Cursor]::Position

    $TargetX = Get-Random -Minimum 1 -Maximum $ScreenWidth
    $TargetY = Get-Random -Minimum 1 -Maximum $ScreenHeight

    $Steps = 50
    $Delay = 10  # milliseconds

    $StepX = ($TargetX - $Mouse.X) / $Steps
    $StepY = ($TargetY - $Mouse.Y) / $Steps

    for ($i = 1; $i -le $Steps; $i++) {
        $Mouse.X += [math]::Round($StepX + (Get-Random -Minimum -5 -Maximum 5))
        $Mouse.Y += [math]::Round($StepY + (Get-Random -Minimum -5 -Maximum 5))
        [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($Mouse.X, $Mouse.Y)
        Start-Sleep -Milliseconds $Delay
    }
}

while ($true) {
    Move-Mouse
    Start-Sleep -Seconds 1
}
