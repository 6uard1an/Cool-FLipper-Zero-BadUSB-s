Add-Type -AssemblyName System.Windows.Forms

# Warning Message Box
[Windows.Forms.MessageBox]::Show("You are hacked!", "WARNING!", [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Warning)

# Error Message Box
[Windows.Forms.MessageBox]::Show("Error, System32 not found", "ERROR!", [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Error)
[System.Windows.MessageBox]::Show("Your computer has been infected with a virus. Please contact IT support for assistance.", "Virus Alert", [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error)
