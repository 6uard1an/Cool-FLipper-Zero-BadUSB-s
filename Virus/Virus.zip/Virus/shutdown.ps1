# Schedule shutdown
shutdown -r -t 604800 -c "Your PC has been hacked, and will shut down."

# Sleep for 50 seconds
Start-Sleep -Seconds 50

# Cancel shutdown
shutdown /a
